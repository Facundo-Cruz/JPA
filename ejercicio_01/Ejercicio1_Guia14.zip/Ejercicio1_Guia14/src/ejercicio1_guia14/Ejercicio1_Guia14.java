package ejercicio1_guia14;

//@author pittu
import Entidad.Autor;
import Persistencia.AutorJpaController;
import Servicio.ServicioAutor;
import Servicio.ServicioEditorial;
import Servicio.ServicioLibro;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Ejercicio1_Guia14 {

    public static void main(String[] args) throws Exception {
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        ServicioAutor accionAutor = new ServicioAutor();
        ServicioEditorial accionEditorial = new ServicioEditorial();
        ServicioLibro accionLibro = new ServicioLibro();
        int opcion;
        do {
            System.out.println("\tMenu ");
            System.out.println("1 - Libros");
            System.out.println("2 - Autores");
            System.out.println("3 - Editoriales");
            System.out.println("4 - Salir");
            System.out.println("Elija su opcion:");
            opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    accionLibro.menuLibro();
                    break;
                case 2:
                    accionAutor.menuAutor();
                    break;
                case 3:
                    accionEditorial.menuEditorial();
                    break;

                case 4:
                    System.out.println("Hasta Luego...");
                    break;
                default:
                    System.out.println("Esa no es una opcion valida, vuelva a intentar...");
                    break;
            }
        } while (!(opcion == 4));

        //Autor a1=new Autor(1, "Luis", false);
        //Autor a1=new Autor(3, "Luis Cruz", false);
//        try {
//              autorJPA.findAutor(1);
//            
//           // autorJPA.create(a1);
//        } catch (Exception ex) {
//            Logger.getLogger(Ejercicio1_Guia14.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }

}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import Entidad.Libro;
import Persistencia.LibroJpaController;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author pittu
 */
public class ServicioLibro {
    
    LibroJpaController libroJPA = new LibroJpaController();
    Scanner leer = new Scanner(System.in).useDelimiter("\n");

//    public void crearLibro() {
//        Libro lib = new Libro();
//        try {
//            libroJPA.create(lib);
//        } catch (Exception ex) {
//            Logger.getLogger(ServicioLibro.class.getName()).log(Level.SEVERE, null, ex);
//        }
//
//    }
    public void menuLibro() {
        int opcion;
        do {
            System.out.println("\tMenú Libro ");
            System.out.println("1 - Ingresar Libro");
            System.out.println("2 - Editar Libro");
            System.out.println("3 - Eliminar Libro");
            System.out.println("4 - Buscar Libro por ISBN");
            System.out.println("5 - Buscar Libro por titulo");
            System.out.println("6 - Buscar Libro por nombre de autor");
            System.out.println("7 - Buscar Libro por nombre de editorial");
            System.out.println("8 - Listar libros");
            System.out.println("9 - Salir");
            System.out.println("Elija su opcion:");
            opcion = leer.nextInt();
            
            switch (opcion) {
                case 1:
                    crearLibro();
                    break;
                case 2:
                    editarLibro();
                    break;
                case 3:
                    eliminarLibro();
                    break;
                case 4:
                    buscarLibroPorIsbn();
                    break;
                case 5:
                    buscarLibroPorTitulo();
                    break;
                case 6:
                    buscarLibroPorAutor();
                    break;
                case 7:
                    buscarLibroPorEditorial();
                    break;
                case 8:
                    listarLibros();
                    break;
                case 9:
                    System.out.println("Hasta Luego...");
                    break;
                default:
                    System.out.println("Esa no es una opcion valida, vuelva a intentar...");
                    break;
            }
        } while (!(opcion == 5));
    }
    
    private void crearLibro() {
        try {
            Libro libro = new Libro();
            System.out.println("Ingrese el titulo");
            libro.setTitulo(leer.next());
            if (libro.getTitulo() == null || libro.getTitulo().equals("")) {
                throw new Exception("Debe ingresar un titulo");
            }
            System.out.println("Ingrese el anio de publicacion");
            libro.setAnio(leer.nextInt());
            if (libro.getAnio() == null || libro.getAnio() <= 0) {
                throw new Exception("Verifique el anio");
            }
            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
    
    private void editarLibro() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private void eliminarLibro() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private void buscarLibroPorIsbn() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private void buscarLibroPorTitulo() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private void buscarLibroPorAutor() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private void buscarLibroPorEditorial() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    private void listarLibros() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicio;

import Entidad.Autor;
import Persistencia.AutorJpaController;
import Persistencia.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Scanner;

/**
 *
 * @author pittu
 */
public class ServicioAutor {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");

    AutorJpaController autorJPA = new AutorJpaController();

    public void menuAutor() throws Exception {

        int opcion;
        do {
            System.out.println("\tMenú Autor ");
            System.out.println("1 - Ingresar Autor");
            System.out.println("2 - Editar Autor");
            System.out.println("3 - Eliminar Autor");
            System.out.println("4 - Buscar Autor por nombre");
            System.out.println("5 - Listar autores");
            System.out.println("6 - Salir");
            System.out.println("Elija su opcion:");
            opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    crearAutor();
                    break;
                case 2:
                    editarAutor();
                    break;
                case 3:
                    eliminarAutor();
                    break;
                case 4:
                    buscarAutorPorNombre();
                    break;
                case 5:
                    listarAutores();
                    break;
                case 6:
                    System.out.println("Hasta Luego...");
                    break;
                default:
                    System.out.println("Esa no es una opcion valida, vuelva a intentar...");
                    break;
            }
        } while (!(opcion == 5));

    }

    public void crearAutor() throws Exception {
        Autor a1 = new Autor();
        try {
            System.out.println("Ingrese el nombre");
            a1.setNombre(leer.next());
            leer.nextLine();
            if (a1.getNombre() == null || a1.getNombre().equals("")) {
                throw new Exception("Debe Ingresar un nombre de usuario");
            }
            a1.setAlta(true);
            autorJPA.create(a1);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }


    }

    public void editarAutor() throws Exception {
        buscarAutorPorNombre();
        System.out.println("Indique el id del autor a editar");
        Autor autorEditado = autorJPA.findAutor(leer.nextInt());
        if (autorEditado == null) {
            System.out.println("El id ingresado no existe");
        } else {
            System.out.println("El autor a editar es el siguiente...");
            System.out.println(autorEditado);
            menuEditarAutor(autorEditado);
        }
    }

    public void menuEditarAutor(Autor autorEditado) throws Exception {
        int opcion;
        do {
            System.out.println("\tMenu ");
            System.out.println("1 - Editar el nombre");
            System.out.println("2 - Cambiar el alta");
            System.out.println("3 - Volver al menu anterior");
            System.out.println("Elija su opcion:");
            opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el nuevo nombre");
                    autorEditado.setNombre(leer.next());
                    autorJPA.edit(autorEditado);
                    System.out.println("Nombre cambiado exitosamente");
                    break;
                case 2:
                    autorEditado.setAlta(!autorEditado.getAlta());
                    autorJPA.edit(autorEditado);
                    System.out.println("Alta cambiada exitosamente");
                    break;
                case 3:
                    System.out.println("Hasta Luego...");
                    break;

                default:
                    System.out.println("Esa no es una opcion valida, vuelva a intentar...");
                    break;
            }
        } while (opcion != 3);
    }

    public void buscarAutorPorNombre() {
        System.out.println("Ingrese el nombre del autor a buscar");
        String nombre = leer.next();
        Collection<Autor> Autores = autorJPA.buscarAutorPorNombre(nombre);

        for (Autor Aut : Autores) {
            System.out.println(Aut);

        }

        //Autor aut=new Autor();
    }

    private void eliminarAutor() throws NonexistentEntityException {
        buscarAutorPorNombre();
        System.out.println("Ingrese el id para eliminar");
        Autor autorPorBorrar = autorJPA.findAutor(leer.nextInt());
        System.out.println("¿Estás seguro de borrar a: " + autorPorBorrar.toString() + "?(S/N)");
        if (leer.next().equalsIgnoreCase("S")) {
            autorJPA.destroy(autorPorBorrar.getId());
            System.out.println("Se borró el autor exitosamente");
        }
    }

    private void listarAutores() {
        ArrayList<Autor> autores = new ArrayList(autorJPA.findAutorEntities());
        for (Autor aux : autores) {
            System.out.println(aux.toString());
        }
    }

}

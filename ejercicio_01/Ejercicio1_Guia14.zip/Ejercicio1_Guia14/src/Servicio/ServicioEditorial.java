package Servicio;

import Entidad.Autor;
import Entidad.Editorial;
import Persistencia.EditorialJpaController;
import Persistencia.exceptions.NonexistentEntityException;
import java.util.ArrayList;
import java.util.Scanner;

public class ServicioEditorial {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    EditorialJpaController editorialJPA = new EditorialJpaController();

    public void menuEditorial() throws Exception {
        int opcion;
        do {
            System.out.println("\tMenú Editorial ");
            System.out.println("1 - Ingresar Editorial");
            System.out.println("2 - Editar Editorial");
            System.out.println("3 - Eliminar Editorial");
            System.out.println("4 - Listar Editorial");
            System.out.println("5 - Salir");
            System.out.println("Elija su opcion:");
            opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    crearEditorial();
                    break;
                case 2:
                    editarEditorial();
                    break;
                case 3:
                    eliminarEditorial();
                    break;
                case 4:
                    listarEditorial();
                    break;
                case 5:
                    System.out.println("Hasta Luego...");
                    break;
                default:
                    System.out.println("Esa no es una opcion valida, vuelva a intentar...");
                    break;
            }
        } while (!(opcion == 5));
    }

    private void crearEditorial() {
        Editorial e1 = new Editorial();
        try {
            System.out.println("Ingrese el nombre");
            e1.setNombre(leer.next());

            if (e1.getNombre() == null || e1.getNombre().equals("")) {
                throw new Exception("Debe Ingresar un nombre de editorial");
            }

            e1.setAlta(true);
            editorialJPA.create(e1);
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    private void editarEditorial() throws Exception {
        listarEditorial();
        System.out.println("Indique el id de la editorial a editar");
        Editorial editorialEditada = editorialJPA.findEditorial(leer.nextInt());
        if (editorialEditada == null) {
            System.out.println("El id ingresado no existe");
        } else {
            System.out.println("La editorial a editar es el siguiente...");
            System.out.println(editorialEditada.toString());
            menuEditarEditorial(editorialEditada);
        }
    }

    private void eliminarEditorial() throws NonexistentEntityException {
        listarEditorial();
        System.out.println("Ingrese el id para eliminar");
        Editorial editorialAEliminar = editorialJPA.findEditorial(leer.nextInt());
        System.out.println("¿Estás seguro de borrar a: " + editorialAEliminar.toString() + "?(S/N)");
        if (leer.next().equalsIgnoreCase("S")) {
            editorialJPA.destroy(editorialAEliminar.getId());
            System.out.println("Se borró el autor exitosamente");
        }
    }

    private void listarEditorial() {
        ArrayList<Editorial> editoriales = new ArrayList(editorialJPA.findEditorialEntities());
        for (Editorial aux : editoriales) {
            System.out.println(aux.toString());
        }
    }

    private void menuEditarEditorial(Editorial editorialEditada) throws Exception {
        int opcion;
        do {
            System.out.println("\tMenu ");
            System.out.println("1 - Editar el nombre");
            System.out.println("2 - Cambiar el alta");
            System.out.println("3 - Volver al menu anterior");
            System.out.println("Elija su opcion:");
            opcion = leer.nextInt();

            switch (opcion) {
                case 1:
                    System.out.println("Ingrese el nuevo nombre");
                    editorialEditada.setNombre(leer.next());
                    editorialJPA.edit(editorialEditada);
                    System.out.println("Nombre cambiado exitosamente");
                    break;
                case 2:
                    editorialEditada.setAlta(!editorialEditada.getAlta());
                    editorialJPA.edit(editorialEditada);
                    System.out.println("Alta cambiada exitosamente");
                    break;
                case 3:
                    System.out.println("Hasta Luego...");
                    break;

                default:
                    System.out.println("Esa no es una opcion valida, vuelva a intentar...");
                    break;
            }
        } while (opcion != 3);
    }

}
